import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report, ConfusionMatrixDisplay
# Load the dataset
df = pd.read_csv("credit_card_fraud_dataset.csv")
print(df.head())

# Check for missing and duplicates
print(df.isnull().sum())
df.drop_duplicates(inplace=True)

#  data distribution
print(df.describe())
print(df['IsFraud'].value_counts())
# Boxplot of transaction amounts
sns.boxplot(x='IsFraud', y='Amount', data=df)
plt.title('Transaction Amount by Fraud Status')
plt.show()

# Transaction time distribution
df['TransactionDate'].hist(bins=50)
plt.title('Transaction Time Distribution')
plt.xlabel('TransactionDate')
plt.ylabel('Frequency')
plt.show()

# Correlation heatmap
corr = df.corr()
sns.heatmap(corr, cmap='coolwarm', annot=True)
plt.title('Feature Correlation')
plt.show()
# Transactions over a threshold amount
fraud_high_amount = df[df['Amount'] > 1000]
print(fraud_high_amount)

# Duplicate transactions in a short time
df['Duplicate'] = df.duplicated(subset=['Transaction_ID', 'Amount', 'TransactionDate'], keep=False)
print(df[df['Duplicate']])
#machine learning
#data preparation
X = df.drop(['IsFraud'], axis=1)
y = df['IsFraud']

# training and test sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)

# Random Forest Classifier
model = RandomForestClassifier()
model.fit(X_train, y_train)

#model evaluation
y_pred = model.predict(X_test)
print(classification_report(y_test, y_pred))

# Feature importance
importance = model.feature_importances_
for i, v in enumerate(importance):
    print(f"Feature {i}: {v}")
# Confusion Matrix
ConfusionMatrixDisplay.from_predictions(y_test, y_pred)
plt.title('Confusion Matrix')
plt.show()

# Fraud distribution
sns.countplot(x='Fraud', data=df)
plt.title('Fraud Distribution')
plt.xlabel('Fraud Status')
plt.ylabel('Count')
plt.show()
# results
print("Anomalies detected include transactions above the threshold amount and duplicate transactions.")
print("High-risk patterns involve accounts with multiple high-value transactions within short periods.")
print("Model performance metrics:")
print(classification_report(y_test, y_pred))